//
//  GuessTheFlagApp.swift
//  GuessTheFlag
//
//  Created by Kunwardeep Singh on 2021-05-29.
//

import SwiftUI

@main
struct GuessTheFlagApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
